﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Threading;
using System.Windows.Data;
using System.Windows.Media.Animation;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public struct Data
    {
        double Angle;
        int X;
        int Y;
        public Data(int Angle, int Index, int Index2)
        {
            this.Angle = Angle;
            this.X = Index;
            this.Y = Index2;
        }
        public double AngleImage
        {
            get
            {
                return this.Angle;
            }
            set
            {
                if (value >= 0)
                    this.Angle = value;
            }
        }
        public int SelectedX
        {
            get
            {
                return this.X;
            }
            set
            {
                this.X = value;
            }
        }
        public int SelectedY
        {
            get
            {
                return this.Y;
            }
            set
            {
                this.Y = value;
            }
        }
    }
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;
        private int Count = 0;
        private int CountMove;
        private int[,] Map;
        private Thread thread;
        public MainWindow()
        {
            InitializeComponent();
            Color color = Color.FromRgb(204, 204, 204);
            this.Background = new SolidColorBrush(color);
            Menu1.Background = new SolidColorBrush(color);
            color = Color.FromRgb(0, 255, 1);
            ProgressBar1.Foreground = new SolidColorBrush(color);
            this.timer = new DispatcherTimer();
            this.timer.Tick += dispatcherTimer_Tick;
            this.timer.Interval = new TimeSpan(0, 0, 1);
            StartGame();
        }
        private void StartGame()
        {
            Map = new int[,]
            {
                    {3,1,3,0,2,3,1},
                    {2,0,2,0,2,2,0 },
                    {5,0,3,3,3,1,5 },
                    {3,1,2,5,1,4,2 },
                    {11,11,11,11,11,11,11 }
            };

            this.ProgressBar1.Minimum = 0;
            this.ProgressBar1.Maximum = 20;
            this.ProgressBar1.IsIndeterminate = false;
            this.CountMove = 20;
            this.Count = 0;
            this.NewGame.IsEnabled = false;

            for (int a = 0, c = 3; a < Map.GetLength(0); a++, c++)
            {
                for (int b = 0; b < Map.GetLength(1); b++)
                {
                    if (Map[a, b] == 0)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/3.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        RotateTransform r = new RotateTransform(90);
                        im.RenderTransform = r;
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        im.MouseDown += Image1_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 90;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                    if (Map[a, b] == 1)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/3.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        RotateTransform r = new RotateTransform(0);
                        im.RenderTransform = r;
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        im.MouseDown += Image1_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 0;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                    if (Map[a, b] == 2)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/2.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        im.MouseDown += Image2_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 0;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                    else if (Map[a, b] == 3)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/2.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        RotateTransform r = new RotateTransform(90);
                        im.RenderTransform = r;
                        im.MouseDown += Image2_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 90;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                    else if (Map[a, b] == 4)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/2.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        RotateTransform r = new RotateTransform(180);
                        im.RenderTransform = r;
                        im.MouseDown += Image2_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 180;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                    else if (Map[a, b] == 5)
                    {
                        Image im = new Image();
                        BitmapImage myBitmapImage = new BitmapImage();
                        myBitmapImage.BeginInit();
                        myBitmapImage.UriSource = new Uri(@"Image/2.png", UriKind.Relative);
                        myBitmapImage.EndInit();
                        im.Source = myBitmapImage;
                        Grid.SetRow(im, c);
                        Grid.SetColumn(im, b);
                        RotateTransform r = new RotateTransform(270);
                        im.RenderTransform = r;
                        im.RenderTransformOrigin = new Point(0.5, 0.5);
                        Grid1.Children.Add(im);
                        im.MouseDown += Image2_MouseDown;
                        Data link = new Data();
                        link.AngleImage = 270;
                        link.SelectedX = a;
                        link.SelectedY = b;
                        im.Tag = link;
                    }
                }
            }
            for (int a = 0; a < Grid1.Children.Count; a++)
            {
                if (Grid1.Children[a].GetType() != typeof(Menu))
                    Grid1.Children[a].IsEnabled = false;
            }
        }
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (this.Count < 20)
            {
                this.Count++;
                if (this.Count >= 20)
                {
                    this.timer.Stop();
                    MessageBox.Show("Время вышло!");
                    for (int a = 0; a < Grid1.Children.Count; a++)
                    {
                        if (Grid1.Children[a].GetType() != typeof(Menu))
                            Grid1.Children[a].IsEnabled = false;
                    }
                }
            }
        }
        private void Image2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (this.CountMove >= 1)
            {
                this.Label1.Content = "Ходов осталось: " + --this.CountMove;
                Image im = sender as Image;
                RotateTransform r = new RotateTransform();
                Data link = (Data)im.Tag;
                r.Angle = link.AngleImage;
                r.Angle += 90;
                r = new RotateTransform(r.Angle);

                if (r.Angle == 0) // слева вниз
                    this.Map[link.SelectedX, link.SelectedY] = 2;
                else if (r.Angle == 90) // слева вверх 
                    this.Map[link.SelectedX, link.SelectedY] = 3;
                else if (r.Angle == 180) // сверху вправо
                    this.Map[link.SelectedX, link.SelectedY] = 4;
                else if (r.Angle == 270) // право вниз
                    this.Map[link.SelectedX, link.SelectedY] = 5;
                else
                {
                    r.Angle = 0;
                    this.Map[link.SelectedX, link.SelectedY] = 2;
                }
                im.RenderTransform = r;
                link.AngleImage = r.Angle;
                im.Tag = link;
            }
            else
            {
                timer.Stop();
                for (int a = 0; a < Grid1.Children.Count; a++)
                {
                    if (Grid1.Children[a].GetType() != typeof(Menu))
                        Grid1.Children[a].IsEnabled = false;
                }
                ProgressBar1.BeginAnimation(ProgressBar.ValueProperty, null);
                MessageBox.Show("Ходов больше нет!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void Image1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (this.CountMove >= 1)
            {
                this.Label1.Content = "Ходов осталось: " + --this.CountMove;
                Image im = sender as Image;
                RotateTransform r = new RotateTransform();
                Data link = (Data)im.Tag;
                r.Angle = link.AngleImage;

                if (r.Angle == 0)
                    r.Angle += 90;
                else
                    r.Angle = 0;

                r = new RotateTransform(r.Angle);
                if (r.Angle == 0)
                    this.Map[link.SelectedX, link.SelectedY] = 1;
                else if (r.Angle == 90)
                    this.Map[link.SelectedX, link.SelectedY] = 0;

                im.RenderTransform = r;
                link.AngleImage = r.Angle;
                im.Tag = link;
            }
            else
            {
                timer.Stop();
                for (int a = 0; a < Grid1.Children.Count; a++)
                {
                    if (Grid1.Children[a].GetType() != typeof(Menu))
                        Grid1.Children[a].IsEnabled = false;
                }
                ProgressBar1.BeginAnimation(ProgressBar.ValueProperty, null);
                MessageBox.Show("Ходов больше нет!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void DisplayTrumpet (String path,int X,int Y,int Angle)
        {
            object obj = new object();
            lock (obj)
            {
                Grid1.Dispatcher.BeginInvoke(new Action(delegate ()
                {
                    Image im = new Image();
                    BitmapImage myBitmapImage = new BitmapImage();
                    myBitmapImage.BeginInit();
                    myBitmapImage.UriSource = new Uri(path, UriKind.Relative);
                    myBitmapImage.EndInit();
                    im.Source = myBitmapImage;
                    Grid.SetRow(im, X + 3);
                    Grid.SetColumn(im, Y);
                    RotateTransform r = new RotateTransform(Angle);
                    im.RenderTransform = r;
                    im.RenderTransformOrigin = new Point(0.5, 0.5);
                    Grid1.Children.Add(im);
                }));
            }
            Thread.Sleep(300);
        }
        private void CheckRoad()
        {

            int X = 0;
            int Y = 0;
            int[,] Temp = new int[Map.GetLength(0), Map.GetLength(1)];

            for (int a = 0; a < this.Map.GetLength(0); a++)
            {
                for (int b = 0; b < this.Map.GetLength(1); b++)
                    Temp[a, b] = Map[a, b];
            }
            while (true)
            {
                //MessageBox.Show(Temp[X, Y].ToString());
                if (Y == 6 && X == 3)
                {
                    MessageBox.Show("Уровень пройден!!", "Победа!", MessageBoxButton.OK, MessageBoxImage.Information);
                    break;
                }

                if (Temp[X, Y] == 0) // прямая
                {
                    Boolean Flag = false;
                    if (X - 1 >= 0)
                    {
                        if (Temp[X - 1, Y] != 10)
                        {
                            if (Temp[X - 1, Y] == 2 || Temp[X - 1, Y] == 5 || Temp[X - 1, Y] == 0)
                            {
                                Temp[X, Y] = 10;

                                DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                                X--;
                                Flag = true;
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    if (X + 1 < 5)
                    {
                        if (Flag == false)
                        {
                            if (Temp[X + 1, Y] != 10)
                            {
                                if (Temp[X + 1, Y] == 3 || Temp[X + 1, Y] == 4 || Temp[X + 1, Y] == 0)
                                {
                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                                    X++;
                                }
                                else
                                {
                                    DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                                    MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                    break;
                                }
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/3.1.png", X, Y, 90);
                        MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }
                else if (Temp[X, Y] == 1)
                {
                    Boolean Flag = false;
                    if (Y - 1 >= 0)
                    {
                        if (Temp[X, Y - 1] != 10)
                        {
                            if (Temp[X, Y - 1] == 4 || Temp[X, Y - 1] == 5 || Temp[X, Y - 1] == 1)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                Y--;
                                Flag = true;
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    if (Y + 1 < 7)
                    {
                        if (Flag == false)
                        {
                            if (Temp[X, Y + 1] != 10)
                            {
                                if (Temp[X, Y + 1] == 2 || Temp[X, Y + 1] == 3 || Temp[X, Y + 1] == 1)
                                {

                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                    Y++;
                                }
                            }

                            else
                            {
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                        MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }
                else if (Temp[X, Y] == 4) // сверху вправо 
                {
                    Boolean Flag = false;
                    if (X - 1 >= 0)
                    {
                        if (Temp[X - 1, Y] != 10)
                        {
                            if (Temp[X - 1, Y] == 5 || Temp[X - 1, Y] == 2 || Temp[X - 1, Y] == 0)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                                X--;
                                Flag = true;
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    if (Y + 1 < 7)
                    {
                        if (Flag == false)
                        {
                            if (Temp[X, Y + 1] != 10)
                            {
                                if (Temp[X, Y + 1] == 3 || Temp[X, Y + 1] == 1 || Temp[X, Y + 1] == 2)
                                {
                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                                    Y++;
                                }
                                else
                                {
                                    DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                                    MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                    break;
                                }
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/2.1.png", X, Y, 180);
                        MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }
                else if (Temp[X, Y] == 3)
                {
                    Boolean Flag = false;
                    if (Y - 1 >= 0)
                    {
                        if (Temp[X, Y - 1] != 10)
                        {
                            if (Temp[X, Y - 1] == 4 || Temp[X, Y - 1] == 1 || Temp[X, Y - 1] == 5)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 90);
                                Y--;
                                Flag = true;
                            }
                        }
                    }
                    if (X - 1 >= 0)
                    {
                        if (Flag == false)
                        {
                            if (Temp[X - 1, Y] != 10)
                            {
                                if (Temp[X - 1, Y] == 5 || Temp[X - 1, Y] == 0 || Temp[X - 1, Y] == 2)
                                {

                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/2.1.png", X, Y, 90);
                                    X--;
                                }
                            }
                            else
                            {
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 90);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/2.1.png", X, Y, 90);
                        MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }
                else if (Temp[X, Y] == 5)
                {
                    Boolean Flag = false;
                    if (X + 1 < 5)
                    {
                        if (Temp[X + 1, Y] != 10)
                        {
                            if (Temp[X + 1, Y] == 0 || Temp[X + 1, Y] == 3 || Temp[X + 1, Y] == 4)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 270);
                                X++;
                                Flag = true;
                            }
                        }
                    }
                    if (Y + 1 < 7)
                    {
                        if (Temp[X, Y + 1] != 10)
                        {
                            if (Temp[X, Y + 1] == 2 || Temp[X, Y + 1] == 3 || Temp[X, Y + 1] == 1)
                            {
                                if (Flag == false)
                                {
                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/2.1.png", X, Y, 270);
                                    Y++;
                                }
                            }
                        }
                        else
                        {
                            DisplayTrumpet(@"Image/2.1.png", X, Y, 270);
                            MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                            break;
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/2.1.png", X, Y, 270);
                        MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }

                else if (Temp[X, Y] == 1)
                {
                    if (Y + 1 < 7)
                    {
                        if (Temp[X, Y + 1] != 10)
                        {
                            if (Temp[X, Y + 1] == 3 || Temp[X, Y + 1] == 2 || Temp[X, Y + 1] == 1)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                Y++;
                            }
                        }
                    }
                    if (Y - 1 >= 0)
                    {
                        if (Temp[X, Y - 1] != 10)
                        {
                            if (Temp[X, Y - 1] == 4 || Temp[X, Y - 1] == 5 || Temp[X, Y - 1] == 1)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                                if (Temp[X, Y - 1] == 4)
                                    X--;
                                else if (Temp[X, Y - 1] == 5)
                                    X++;
                                else
                                    Y++;
                            }
                        }
                        else
                        {
                            DisplayTrumpet(@"Image/3.1.png", X, Y, 0);
                            MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                            break;
                        }
                    }
                }
                else if (Temp[X, Y] == 2)
                {
                    Boolean Flag = false;
                    if (Y - 1 >= 0)
                    {
                        if (Temp[X, Y - 1] != 10)
                        {
                            if (Temp[X, Y - 1] == 1 || Temp[X, Y - 1] == 4 || Temp[X, Y - 1] == 5)
                            {
                                Temp[X, Y] = 10;
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 0);
                                Y--;
                                Flag = true;
                            }
                        }
                    }
                    if (X + 1 < 5)
                    {
                        if (Temp[X + 1, Y] != 10)
                        {
                            if (Temp[X + 1, Y] == 0 || Temp[X + 1, Y] == 3 || Temp[X + 1, Y] == 4)
                            {
                                if (Flag == false)
                                {
                                    Temp[X, Y] = 10;
                                    DisplayTrumpet(@"Image/2.1.png", X, Y, 0);
                                    X++;
                                }

                            }
                            else
                            {
                                DisplayTrumpet(@"Image/2.1.png", X, Y, 0);
                                MessageBox.Show("Нет выхода!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                                break;
                            }
                        }
                    }
                    else
                    {
                        DisplayTrumpet(@"Image/2.1.png", X, Y, 0);
                        MessageBox.Show("Нет выхода!!", "Вы проиграли!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }

                }
            }
        }
        private void Image1_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            timer.Stop();
            ProgressBar1.BeginAnimation(ProgressBar.ValueProperty, null);
            this.thread = new Thread(CheckRoad);
            this.thread.Name = "New Thread";
            thread.SetApartmentState(ApartmentState.STA);
            this.thread.Start();
            Image1.IsEnabled = false;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            ProgressBar1.BeginAnimation(ProgressBar.ValueProperty, null);
            Grid1.Children.Clear();
            Image1.IsEnabled = true;
            this.Start.IsEnabled = true;
            for (int a = 0; a < Grid1.Children.Count; a++)
                Grid1.Children[a].IsEnabled = true;
                StartGame();

            this.Grid1.Children.Add(Border1);
            this.Grid1.Children.Add(Grid2);
            this.Grid1.Children.Add(Image1);
            this.Grid1.Children.Add(Menu1);
            this.Grid1.Children.Add(StackPanel1);
            this.Label1.Content = "Ходов осталось: " + this.CountMove;
            this.Label2.Content = "Уровень: 1";
        }
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Игра \"Водопроводчик\" - это очередная головоломка, для решения которой, от вас потребуется максимальная внимательность за короткий промежуток времени. В игровом поле, присутствует очень много лишних частей трубы, которые сбивают с толку. Для управления и вращения элементами, используйте мышку, нажимая на кусочки труб.Когда соберете проход, нажмите на водопроводный кран.", "Правила", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            this.NewGame.IsEnabled = true;
            this.Start.IsEnabled = false;
            for (int a = 0; a < Grid1.Children.Count; a++)
            {
                if (Grid1.Children[a].GetType() != typeof(Menu))
                    Grid1.Children[a].IsEnabled = true;
            }
            Duration duration = new Duration(TimeSpan.FromSeconds(20));
            DoubleAnimation doubleanimation = new DoubleAnimation(20, duration);
            ProgressBar1.BeginAnimation(ProgressBar.ValueProperty, doubleanimation);
            this.timer.Start();
            this.Label1.Content = "Ходов осталось: " + this.CountMove;
            this.Label2.Content = "Уровень: 1";
        }
        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Особенность игры в том,что она динамически ищет ход,все проходы нигде не сохранены,и в будущем будет добавлено генерацию карт.", "Особенность игры", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (thread != null)
                thread.Abort();
        }
    }
}
